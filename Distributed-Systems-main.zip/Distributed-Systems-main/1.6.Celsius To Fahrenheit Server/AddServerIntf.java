import java.rmi.*;
public interface AddServerIntf extends Remote { 
//method declaration 
double ctof(double d1) throws RemoteException;
}
