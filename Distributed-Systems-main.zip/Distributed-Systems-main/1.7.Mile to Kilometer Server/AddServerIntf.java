import java.rmi.*;
public interface AddServerIntf extends Remote { 
//method declaration 
double mtok(double d1) throws RemoteException;
}
